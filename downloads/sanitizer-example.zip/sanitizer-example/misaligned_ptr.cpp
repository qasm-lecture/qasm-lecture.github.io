#include <array>
#include <iomanip>
#include <iostream>

int main() {
  std::array<char, 10> array{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

  for (size_t i{0}; i < 3; ++i) {
    const int *p{reinterpret_cast<int*>(array.data() + i)};
    std::cout << std::hex << *p << '\n';
  }
}
