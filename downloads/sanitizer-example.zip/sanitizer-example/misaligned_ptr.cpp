#include <array>
#include <iomanip>
#include <iostream>

int main() {
  std::array<char, 15> array{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

  for (size_t i{0}; i < 3; ++i) {
    // at least one of these reads must be completely misaligned
    const auto *p{reinterpret_cast<double*>(array.data() + i)};
    std::cout << std::hex << *p << '\n';
  }
}
