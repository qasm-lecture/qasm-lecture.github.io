#include <future>
#include <iostream>

int main() {
  int x{1};

  auto f1{std::async(std::launch::async, [&x](){ x += 10; })};
  auto f2{std::async(std::launch::async, [&x](){ x *=  7; })};
  auto f3{std::async(std::launch::async, [&x](){ x /=  2; })};

  f1.wait();
  f2.wait();
  f3.wait();

  std::cout << "Value of x: " << x <<  '\n';
}
