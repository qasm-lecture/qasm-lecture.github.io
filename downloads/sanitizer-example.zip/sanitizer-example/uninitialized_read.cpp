#include <array>
#include <iostream>

int main(int argc, char** argv) {
  std::array<int, 10> a;
  a[5] = 0;

  if (a[argc]) {
    std::cout << "Foo.\n";
  } else {
    std::cout << "Bar.\n";
  }
}

