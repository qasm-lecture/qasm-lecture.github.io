#include <iostream>
#include <vector>

int main() {
  auto *v{new std::vector<int>{10, 20, 30}};

  for (const auto &x : *v) {
    std::cout << x << ", ";
  }
  std::cout << '\n';

  delete v;

  for (const auto &x : *v) {
    std::cout << x << ", ";
  }
  std::cout << '\n';
}
