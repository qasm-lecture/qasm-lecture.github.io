#include <iostream>
#include <limits>

int main(int argc, char **argv) {
  int x{std::numeric_limits<int>::max()};

  int y{x + argc};

  std::cout << x << " + " << argc << " = " << y << '\n';
}
