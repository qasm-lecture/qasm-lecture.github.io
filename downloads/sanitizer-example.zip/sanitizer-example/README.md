# Sanitizer examples

This folder contains programs with buggy/undefined behavior that do not crash
when run normally.
When compiled with sanitizers, they will crash with nice error messages.

## Exercise

- Read the programs. Try to see the bugs that *every* program contains.
- Build the programs without sanitizers and run them.
  Do they produce errors or behave strange?
- Build the programs with sanitizers. Read the compiler/sanitizer documentation
  and try to foresee which sanitizer will trigger on which program!
- Also play with different -O optimization settings.

## Files of Interest

- Each .cpp file is an individual program with specific bugs
- `release.nix`: Contains nix expressions for each sanitizer

## Commands of Interest

### Normal build flow

For every file `programname.cpp` you can run:

```bash
$ make programname
$ ./programname
```

In order to build and run with sanitizers, you can run:

```bash
$ make SAN=xxx programname
$ ./programname
```

If make does not rebuild a program because it remained unchanged, delete the
program executable or run `make clean`.

Note that `nix-shell` put you into an environment with GCC but not all sanitizers
are available for GCC. Some need Clang.

### Build all apps with nix-build with specific sanitizer

This command builds all apps with a specific sanitizer and puts them into the
`release/` folder.

```bash
$ nix-build release.nix -A <sanitizer>
```

See list of available sanitizers in the `release.nix` file.
