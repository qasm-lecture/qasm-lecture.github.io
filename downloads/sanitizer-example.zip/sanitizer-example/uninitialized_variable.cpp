#include <iostream>

struct S {
  int x;
};

void f(struct S s){
  std::cout << "struct S content: " << s.x << '\n';
}

void test() {
  struct S s;
  f(s); // We're copying an uninitialized var and currently it's undetected
}

int main(){
  test();
}
