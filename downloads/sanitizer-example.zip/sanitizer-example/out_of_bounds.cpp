#include <iostream>
#include <vector>

int main() {
  std::vector<int> v{1, 2, 3, 4, 5, 6};

  std::cout << "The vector contains " << v.size() << " items\n";

  size_t input;
  while (std::cin >> input) {
    std::cout << "v[" << input << "]: " << v[input] << '\n';
  }
}

