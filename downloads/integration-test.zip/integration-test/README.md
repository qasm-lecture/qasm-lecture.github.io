# Python Histogram Web Client with isolated integration test, nix version

This folder contains a python app that accepts an URL as command line parameter
and will download it in order to decompose its content into a histogram of words.
It is assumed that all URLs point to plain text documents.

The task is to integration-test this script against real websites.

## Commands of Interest

- Re-run the app during development

```bash
$ nix-shell
$ python3 histogram/app.py
```

Try this example URL: https://tools.ietf.org/rfc/rfc7994.txt

- Build the app

```bash
nix-build
```

The app is now accessible in the `bin/webclient` subfolder of where `result`
points to in the nix store

## Exercise

Complete the function in `histogram/histogram.py` so that it produces a useful
result. Then think about how to test the whole application.
