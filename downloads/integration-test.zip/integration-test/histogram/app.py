import requests
import sys

from histogram import histogram

# This application ought to be run with an HTTP URL that contains text only
# and prints a histogram of the word frequencies that this text contains
#
# Example URL: https://tools.ietf.org/rfc/rfc7994.txt

def main():
    url = sys.argv[1]

    # Post a GET request and only accept plain text content
    r = requests.get(url, headers={'Content-Type': 'text/plain'})

    if r.status_code != 200:
        print("Can't get content from {}".format(url))
        sys.exit(1)

    # Split the content into a list of words without spaces
    words = r.text.split()

    # Transform all words to lowercase
    lowercased_words = [w.lower() for w in words]

    # Obtain histogram
    hist = histogram(lowercased_words)

    # Print histogram to the user
    for key, counter in sorted(hist.items(), key=lambda item: item[1]):
        print ("{} --> {}".format(key, counter))

if __name__ == "__main__":
    main()
