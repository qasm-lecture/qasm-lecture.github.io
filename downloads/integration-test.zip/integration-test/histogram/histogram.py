
# Accept a list of words like ["a", "b", "a", "c"] and return a histogram
# like {"a": 2, "b": 1, "c": 1}

def histogram(word_list):
    hist = {};
    return hist
