from setuptools import setup, find_packages

setup(
    name='histogram-webclient',
    packages=["histogram"],
    install_requires=[],
    entry_points = {
        'console_scripts': [
            'webclient = histogram.app:main'
        ]
    }
)
