#! /usr/bin/env nix-shell
#! nix-shell -i runghc -p "haskellPackages.ghcWithPackages (pkgs: with pkgs; [ hspec linear QuickCheck ])"

{-# LANGUAGE TemplateHaskell #-}
import           Test.Hspec
import           Test.QuickCheck     hiding ((.&.))
import           Test.QuickCheck.All

import           Data.Bits
import           Data.Word

-------------------------------------------------------------------------------
-- Helper functions and basic types -------------------------------------------
-------------------------------------------------------------------------------

highestBit :: Word -> Int
highestBit x = finiteBitSize x - countLeadingZeros x - 1

lowestBit :: Word -> Int
lowestBit = countTrailingZeros

data Crd = Crd Word Int
  deriving (Eq, Show)

-------------------------------------------------------------------------------
-- Implementation -------------------------------------------------------------
-------------------------------------------------------------------------------

toCrds :: Word -> Word -> [Crd]
toCrds base size = [] -- TODO: IMPLEMENT THIS

-------------------------------------------------------------------------------
-- QuickCheck Properties ------------------------------------------------------
-------------------------------------------------------------------------------

-- This property describes that every CRD's base is evenly divisible by
-- its size
prop_divisibility :: Word -> Word -> Bool
prop_divisibility base size = all evenlyDivisible $ toCrds base size
  where
    evenlyDivisible (Crd b o) = b `mod` (1 `shift` o) == 0

-- This property describes that the sizes of the resulting CRDs must all sum
-- up to the original size of the initial range.
prop_sizeInvariant :: Word -> Word -> Bool
prop_sizeInvariant base size = size == summed (toCrds base size)
  where summed = foldl (\accum (Crd _ order) -> accum + (1 `shift` order)) 0

-- This property describes that every CRD must touch its consecutively
-- following neighbor, and they must have strongly monotonously increasing
-- bases.
prop_gapLess :: Word -> Word -> Bool
prop_gapLess base size = case toCrds base size of
  [] -> True
  (x:xs) -> all touching pairs
    where
      pairs = zip (x:xs) xs
      touching (Crd b1 o1, Crd b2 o2) = b1 + (1 `shift` o1) == b2

-- This property describes that the the whole range is covered by the
-- minimal amount of needed CRDs
prop_minimalCrdCount :: Word -> Word -> Bool
prop_minimalCrdCount base size =
  (size <= 1) || length (toCrds base size) == optimalNumber
  where
    end = base + size
    border = end .&. complement ((1 `shift` highestBit size) - 1)
    optimalNumber = popCount (border - base) + popCount (end - border)

-------------------------------------------------------------------------------
-- Some weird template magic to make it automatically run ---------------------
-------------------------------------------------------------------------------

return []
runTests :: IO Bool
runTests = $forAllProperties $
  quickCheckWithResult (stdArgs {maxSuccess = 10000})

main :: IO Bool
main = runTests
