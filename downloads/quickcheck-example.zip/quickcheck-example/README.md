# CRD List Generator

This task is about implementing the `toCrds` function according to CRD rules.

The `toCrds` function accepts two parameters: `a` and `b` from the interval
`[a, b)` and returns a list of CRDs that describe the same interval.
Please have a look at the lecture slides and the blog article
https://galowicz.de/2017/07/02/order2_iterator/ for further explanation.

## Exercise

Delete the content of the `toCrds` function and reimplement it from scratch.

Acceptance criteria:

- The tests succeed.

## Files of Interest

- `Main.hs`: Source implementation

## Commands of Interest

- Only build and run the tests once

```bash
nix-build
```

While working at the code, you most probably want to do have a reload-and-run
workflow in one shell that keeps open while you edit the source code in another
shell or editor:

```bash
$ nix-shell
$ ghcid
```
