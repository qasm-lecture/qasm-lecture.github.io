#pragma once

#include <string>

bool is_valid_mail_address(const std::string &input);
