#include "check_mail.hpp"

#include <algorithm>
#include <set>

/* Important note:
 * this code will not build successfully if the `input` argument variable
 * remains unused!
 */
bool is_valid_mail_address(const std::string &) {
  return false;
}
