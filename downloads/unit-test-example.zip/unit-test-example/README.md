# Unit Test examples

This folder contains a unit test example where a naive email checker is tested.

## Exercise

Delete the contents of `src/check_mail.cpp` and `test/test.cpp` and rewrite
from scratch.

## Files of Interest

- `src`: Folder with library function
- `test`: Folder with unit test code

## Commands of Interest

### Building and Testing the Code

Initial setup:

```bash
$ nix-shell
$ mkdir build
$ cd build
$ cmake ..
```

Still in the nix shell, you can now build the code and run the tests:

```bash
$ make
$ ctest -V
```

In order to build and test in one command, just do:

```bash
$ make && ctest -V
```

### Generate Test Coverage Information

The code must build and the tests must succeed first.

```bash
$ nix-build coverage.nix
```

You can now browse the coverage info in `result/html/index.html`.
