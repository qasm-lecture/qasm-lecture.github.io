#include <check_mail.hpp>

#include <catch2/catch.hpp>

TEST_CASE( "Empty strings and strings without @ are no mail addrs", "[check_mail]") {
  REQUIRE_FALSE( is_valid_mail_address("") );
  REQUIRE_FALSE( is_valid_mail_address("foobar")  );
}

TEST_CASE( "Only proper addrs with @ and proper TLD are accepted", "[check_mail]") {
  REQUIRE( is_valid_mail_address("foo@bar.de") );
  REQUIRE_FALSE( is_valid_mail_address("foo@bar.xyz") );
}

TEST_CASE( "Addrs with multiple @ or bad characters are rejected", "[check_mail]") {
  REQUIRE_FALSE( is_valid_mail_address("!!!@???.de") );
  REQUIRE_FALSE( is_valid_mail_address("foo@ooo@bar.de") );
}
