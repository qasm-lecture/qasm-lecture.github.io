#!/usr/bin/env bash

set -euo pipefail

nsName="foonet$$"

function cleanup() {
  ip netns delete "$nsName"
}

ip netns add "$nsName"
trap cleanup EXIT

ip netns exec "$nsName" ip link set lo up
ip netns exec "$nsName" $@
