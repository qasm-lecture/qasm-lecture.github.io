#!/usr/bin/env bash

set -euo pipefail

for image in Dockerfile.*; do
  ./run_in_docker.sh "$image"
done
