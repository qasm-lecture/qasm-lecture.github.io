#!/usr/bin/env bash

set -euo pipefail

python3 -m http.server &
pid=$!

function cleanup() {
  kill "$pid"
}
trap cleanup EXIT

set -x

output=$(python3 histogram/app.py http://localhost:8000/input.txt)

[[ "$output" =~ "bar --> 3" ]]
[[ "$output" =~ "foo --> 4" ]]

! python3 histogram/app.py http://localhost:8000/does-not-exist.txt

set +x

echo SUCCESS


