#!/usr/bin/env bash

set -euo pipefail

dockerFile=$1

imageName="integration-test-${dockerFile##*.}"

[ -e "$dockerFile" ]

docker build -t "$imageName" - < $dockerFile

docker run                      \
  --network none                \
  -v "$(pwd)":/integration-test \
  -w /integration-test          \
  "$imageName"                  \
  /integration-test/test_app.sh
